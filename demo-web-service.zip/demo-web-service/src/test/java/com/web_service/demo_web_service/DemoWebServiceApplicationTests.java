package com.web_service.demo_web_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
