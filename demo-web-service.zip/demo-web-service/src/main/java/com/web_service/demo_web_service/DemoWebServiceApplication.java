package com.web_service.demo_web_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoWebServiceApplication.class, args);
	}

}
